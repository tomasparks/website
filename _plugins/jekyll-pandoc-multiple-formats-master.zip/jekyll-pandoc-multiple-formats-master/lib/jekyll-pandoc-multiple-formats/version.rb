module JekyllPandocMultipleFormats
  VERSION = "0.0.7"
end
