module Jekyll
  class ResponsiveImage
    VERSION = '0.17.0'.freeze
  end
end
