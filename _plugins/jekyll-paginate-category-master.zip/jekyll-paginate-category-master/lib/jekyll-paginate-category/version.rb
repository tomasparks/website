module Jekyll
  module Paginate
    module Category
      VERSION = "0.1.2"
    end
  end
end
