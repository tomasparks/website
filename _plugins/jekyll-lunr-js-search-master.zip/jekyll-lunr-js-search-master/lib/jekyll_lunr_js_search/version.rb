module Jekyll
  module LunrJsSearch
    VERSION = "3.1.0"
  end
end