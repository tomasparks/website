module Jekyll
class GalleryPage < ReadYamlPage
 def makeThumb(image_path, dest_image, thumb_x, thumb_y, scale_method)
      # create thumbnail if it is not there
      thumbs_dir = File.join(site.dest, @dir, "thumbs")
      #thumbs_dir = File.join(@dir, "thumbs")
      thumb_path = File.join(thumbs_dir, dest_image)

      # create thumbnails
      FileUtils.mkdir_p(thumbs_dir, :mode => 0755)
      if File.file?(thumb_path) == false or File.mtime(image_path) > File.mtime(thumb_path)
        begin
          m_image = ImageList.new(image_path)
          # m_image.auto_orient!
          #m_image.send("resize_to_#{scale_method}!", max_size_x, max_size_y)
          if scale_method == "crop"
            m_image.resize_to_fill!(thumb_x, thumb_y)
          elsif scale_method == "crop_bottom"
            m_image.resize_to_fill!(thumb_x, thumb_y, NorthGravity)
          else
            m_image.resize_to_fit!(thumb_x, thumb_y)
          end
          # strip EXIF from thumbnails. Some browsers, notably, Safari on iOS will try to rotate images according to the 'orientation' tag which is no longer valid in case of thumbnails
          m_image.strip!
          puts "Writing thumbnail to #{thumb_path}"
          m_image.write(thumb_path)
        rescue Exception => e
          puts "Error generating thumbnail for #{image_path}: #{e}"
          puts e.backtrace
        end
      end
      # record the thumbnail
      @site.static_files << GalleryFile.new(@site, @base, thumbs_dir, dest_image)
  end


 def doImages()
    puts "thumbnail destination"
    scale_method = gallery_config["scale_method"] || config["scale_method"] || "fit" # each gallery can have it's own scale method, or use the global scale if defined
    @hidden = gallery_config["hidden"] || false # the gallery can also be hidden by renaming it to start with a dot
    if @hidden
      self.data["sitemap"] = false
      return
    end
    if config["watermark"]      # load watermark image
      wm_img = Image.read(File.join(base, "images",config["watermark"])).first
    end

    puts "process and copy images"
    self.data["captions"] = {}
    date_times = {}
    Dir.foreach(dir) do |image|
      next if image.chars.first == "."
      next unless image.downcase().end_with?(*$file_extensions)

      image_path = File.join(dir, image) # source image short path
      # img_src = site.in_source_dir(image_path) # absolute path for the source image

      puts "extract timestamp"
      if sort_field == "timestamp"
        begin
          #date_times[image] = EXIFR::JPEG.new(image_path).date_time.to_i
          date_times[image]=0
          #  ["DateTime"], ["DateTimeDigitized"], ["DateTimeOriginal"]
          date_array = ImageList.new(image_path).get_exif_by_entry("DateTime")
          if date_array != nil && date_array.length > 0 and date_array[0].length > 1
            date_times[image]=DateTime.strptime(date_array[0][1],"%Y:%m:%d %H:%M:%S").to_time.to_i
          end
          # puts "gtot #{date_array} date" + date_times[image].to_s
        rescue Exception => e
          puts "Error getting date_time "+date_times[image]+" for #{image}: #{e}"
        end
      end
      puts "cleanup, watermark and copy the files"
      puts "Strip out the non-ascii character and downcase the final file name"
      dest_image=image.gsub(/[^0-9A-Za-z.\-]/, '_').downcase
      dest_image_abs_path = site.in_dest_dir(File.join(@dir, dest_image))
      if File.file?(dest_image_abs_path) == false or File.mtime(image_path) > File.mtime(dest_image_abs_path)
        if config["strip_exif"] or config["watermark"] # can't simply copy or symlink, need to pre-process the image
          source_img=ImageList.new(image_path)
          print "Generating #{dest_image}..."
          if config["strip_exif"]
            print "stripping EXIF..."
            source_img.strip!
          end
          if config["watermark"]
            if [source_img.columns,source_img.rows].min < 600
              print "too small to watermark"
            else
              print "watermarking"
              source_img.composite!(wm_img,Magick::SouthEastGravity,20,20,Magick::HardLightCompositeOp).write(dest_image_abs_path)
            end
          end
          puts "."
          source_img.write(dest_image_abs_path)
        elsif symlink
          puts "Symlinking #{image_path} to #{dest_image}..."
          link_src = site.in_source_dir(image_path)
          link_dest = dest_image_abs_path
          @site.static_files.delete_if { |sf|
            sf.relative_path == "/" + image_path
            }
          @site.static_files << GalleryFile.new(site, base, dir, image)
          if File.exists?(link_dest) or File.symlink?(link_dest)
            if not File.symlink?(link_dest)
              puts "#{link_dest} exists but is not a symlink. Deleting."
              File.delete(link_dest)
            elsif File.readlink(link_dest) != link_src
              puts "#{link_dest} points to the wrong file. Deleting."
              File.delete(link_dest)
            end
          end
          if not File.exists?(link_dest) and not File.symlink?(link_dest)
            puts "Symlinking #{link_src} -> #{link_dest}"
            File.symlink(link_src, link_dest)
          end
        else
          puts "Copying #{image_path} to #{dest_image}..."
          FileUtils.cp(image_path,dest_image_abs_path)
        end
      end
      puts "push descriptions if defined"
      if gallery_config.has_key?(image)
        # puts "added ${image} = #{gallery_config[image]}"
        self.data["captions"][dest_image]=gallery_config[image]
      end
      puts "remember the image"
      @images.push(dest_image)
      @site.static_files << GalleryFile.new(site, base, @dir, dest_image)

      puts "make a thumbnail"
      makeThumb(image_path, dest_image, config["thumbnail_size"]["x"] || 400, config["thumbnail_size"]["y"] || 400, scale_method)
      #@site.static_files << GalleryFile.new(site, base, File.join(@dir, "thumbs"), dest_image)

    end
    puts "sort pictures inside the gallery"
    begin
      if sort_field == "timestamp"
        @images.sort! {|a,b|
          if date_times[a] == date_times[b]
            a <=> b # do the name if the timestamps match
          else
            date_times[a] <=> date_times[b]
          end
          }
      else
        @images.sort!
      end
      if gallery_config["sort_reverse"]
        @images.reverse!
      end
    rescue Exception => e
      puts "Error sorting images in gallery #{gallery_name}: #{e}"
      puts e.backtrace
    end

    site.static_files = @site.static_files
    self.data["images"] = @images

    best_image = gallery_config["best_image"] || @images[0]
    best_image.gsub!(/[^0-9A-Za-z.\-]/, '_') # renormalize the name - important in case the best image name is specified via config
    best_image.downcase! # two step because mutating gsub returns nil that's unusable in a compound call
    #best_image = File.join(@dir, best_image)
    self.data["best_image"] = best_image

    # generate best image thumb for the gallery super-index page
    makeThumb(site.in_dest_dir(File.join(@dir, best_image)), "front_"+best_image, config["front_thumb_size"]["x"] || 400, config["front_thumb_size"]["y"] || 400,"crop")

    # generate best image thumb for the header of a gallery index page
    makeThumb(site.in_dest_dir(File.join(@dir, best_image)), "header_"+best_image, config["header_thumb_size"]["x"] || 400, config["header_thumb_size"]["y"] || 400,"crop")

    self.data["header"]["image_fullwidth"] = "thumbs/header_"+best_image # used in the theme
end
end
end
